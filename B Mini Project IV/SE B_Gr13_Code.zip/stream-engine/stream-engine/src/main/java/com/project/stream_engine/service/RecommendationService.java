package com.project.stream_engine.service;

import com.project.stream_engine.model.Movie;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class RecommendationService {

    // The Main AI Function: Returns top 5 similar movies using Cosine Similarity
    public List<Movie> getRecommendations(Movie targetMovie, List<Movie> allMovies) {
        Map<Movie, Double> scores = new HashMap<>();

        // 1. Get the "Vector" (Word Frequencies) of the target movie
        Map<String, Integer> targetVector = getWordFrequencies(targetMovie.getContentVector());

        // 2. Compare it against every other movie
        for (Movie m : allMovies) {
            // Use getId() since id is private
            if (m.getId().equals(targetMovie.getId())) continue;

            Map<String, Integer> otherVector = getWordFrequencies(m.getContentVector());

            // 3. Calculate Cosine Similarity
            double score = calculateCosineSimilarity(targetVector, otherVector);
            scores.put(m, score);
        }

        // 4. Sort by score (Highest match first) and pick top 5
        return scores.entrySet().stream()
                .sorted((a, b) -> Double.compare(b.getValue(), a.getValue())) // Sort descending
                .limit(5)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
    }

    // Helper: Turns text into a Frequency Map (The Vector)
    // Example: "action hero action" -> {action: 2, hero: 1}
    private Map<String, Integer> getWordFrequencies(String text) {
        Map<String, Integer> frequencies = new HashMap<>();
        if (text == null || text.isEmpty()) return frequencies;

        // Remove symbols and convert to lowercase
        String cleanText = text.replaceAll("[^a-zA-Z0-9\\s]", "").toLowerCase();

        for (String word : cleanText.split("\\s+")) {
            frequencies.put(word, frequencies.getOrDefault(word, 0) + 1);
        }
        return frequencies;
    }

    // The Math: Cosine Similarity
    // Formula: (A . B) / (||A|| * ||B||)
    private double calculateCosineSimilarity(Map<String, Integer> vecA, Map<String, Integer> vecB) {
        if (vecA.isEmpty() || vecB.isEmpty()) return 0.0;

        // 1. Calculate Dot Product (Sum of A[i] * B[i])
        double dotProduct = 0.0;
        for (String key : vecA.keySet()) {
            if (vecB.containsKey(key)) {
                dotProduct += vecA.get(key) * vecB.get(key);
            }
        }

        // 2. Calculate Magnitudes (Sqrt of sum of squares)
        double magnitudeA = calculateMagnitude(vecA);
        double magnitudeB = calculateMagnitude(vecB);

        // 3. Final Division
        if (magnitudeA == 0 || magnitudeB == 0) return 0.0;
        return dotProduct / (magnitudeA * magnitudeB);
    }

    private double calculateMagnitude(Map<String, Integer> vector) {
        double sum = 0.0;
        for (int count : vector.values()) {
            sum += count * count;
        }
        return Math.sqrt(sum);
    }
}