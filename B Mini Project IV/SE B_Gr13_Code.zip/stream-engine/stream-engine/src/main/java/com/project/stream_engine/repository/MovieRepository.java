package com.project.stream_engine.repository;

import com.project.stream_engine.model.Movie;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MovieRepository extends MongoRepository<Movie, String> {

    // Search
    List<Movie> findByTitleContainingIgnoreCase(String query);

    // Random Movies (MongoDB specific syntax)
    @Aggregation(pipeline = { "{ $sample: { size: 10 } }" })
    List<Movie> findRandomMovies();

    // Find by Genres (Checks if 'genres' array contains any of the input genres)
    @Query("{ 'genres': { $in: ?0 } }")
    List<Movie> findByGenres(List<String> genres);

    // NEW: Get Top 10 movies sorted by popularity (High to Low) for Trending Page
    List<Movie> findTop10ByOrderByPopularityDesc();
}