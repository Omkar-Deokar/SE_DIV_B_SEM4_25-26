package com.project.stream_engine.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.ArrayList;
import java.util.List;

@Document(collection = "users")
public class User {

    @Id
    private String id;

    private String username;
    private String email;
    private String password;
    private List<String> favoriteGenres = new ArrayList<>();

    // FIX: Removed @DBRef. Now movies are saved directly inside the User.
    // This prevents "disappearing" data issues.
    private List<Movie> watchlist = new ArrayList<>();

    // --- CONSTRUCTORS ---
    public User() {}

    public User(String username, String email, String password, List<String> favoriteGenres) {
        this.username = username;
        this.email = email;
        this.password = password;
        this.favoriteGenres = favoriteGenres;
    }

    // --- GETTERS & SETTERS ---
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public List<String> getFavoriteGenres() { return favoriteGenres; }
    public void setFavoriteGenres(List<String> favoriteGenres) { this.favoriteGenres = favoriteGenres; }

    public List<Movie> getWatchlist() {
        if(watchlist == null) watchlist = new ArrayList<>();
        return watchlist;
    }
    public void setWatchlist(List<Movie> watchlist) { this.watchlist = watchlist; }
}