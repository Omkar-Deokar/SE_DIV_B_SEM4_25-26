package com.project.stream_engine.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.List;

@Document(collection = "movies")
public class Movie {

    @Id
    private String id;

    private String title;
    private String posterUrl;
    private String overview;
    private List<String> genres;

    // 1. NEW FIELD FOR TRENDING
    private Double popularity;

    // --- CONSTRUCTORS ---
    public Movie() {}

    // 2. UPDATED CONSTRUCTOR (Now accepts popularity)
    public Movie(String title, String posterUrl, String overview, List<String> genres, Double popularity) {
        this.title = title;
        this.posterUrl = posterUrl;
        this.overview = overview;
        this.genres = genres;
        this.popularity = popularity;
    }

    // --- GETTERS & SETTERS ---
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getPosterUrl() { return posterUrl; }
    public void setPosterUrl(String posterUrl) { this.posterUrl = posterUrl; }

    public String getOverview() { return overview; }
    public void setOverview(String overview) { this.overview = overview; }

    public List<String> getGenres() { return genres; }
    public void setGenres(List<String> genres) { this.genres = genres; }

    // 3. NEW GETTER & SETTER FOR POPULARITY
    public Double getPopularity() { return popularity; }
    public void setPopularity(Double popularity) { this.popularity = popularity; }

    // For AI Recommendation
    public String getContentVector() {
        String genreString = (genres != null) ? String.join(" ", genres) : "";
        return (title + " " + overview + " " + genreString).toLowerCase();
    }
}