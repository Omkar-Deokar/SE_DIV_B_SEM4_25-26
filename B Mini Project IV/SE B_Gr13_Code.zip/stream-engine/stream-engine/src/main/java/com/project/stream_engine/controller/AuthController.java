package com.project.stream_engine.controller;

import com.project.stream_engine.model.User;
import com.project.stream_engine.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/register")
    public String registerUser(@RequestBody User user) {
        if (userRepository.existsByEmail(user.getEmail())) return "Error: Email already exists!";
        if (userRepository.existsByUsername(user.getUsername())) return "Error: Username is already taken!";
        userRepository.save(user);
        return "User Registered Successfully!";
    }

    @PostMapping("/login")
    public User loginUser(@RequestBody User loginDetails) {
        User user = userRepository.findByUsername(loginDetails.getUsername()).orElse(null);
        if (user != null && user.getPassword().equals(loginDetails.getPassword())) {
            return user;
        }
        return null;
    }

    @PostMapping("/update-genres/{id}")
    public String updateGenres(@PathVariable String id, @RequestBody List<String> genres) {
        return userRepository.findById(id).map(user -> {
            user.setFavoriteGenres(genres);
            userRepository.save(user);
            return "Genres Updated!";
        }).orElse("User not found");
    }

    // --- NEW: Gets fresh user data ---
    @GetMapping("/user/{id}")
    public User getUser(@PathVariable String id) {
        return userRepository.findById(id).orElse(null);
    }
}