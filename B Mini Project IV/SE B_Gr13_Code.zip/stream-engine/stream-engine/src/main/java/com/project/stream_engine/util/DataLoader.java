package com.project.stream_engine.util;

import com.project.stream_engine.model.Movie;
import com.project.stream_engine.repository.MovieRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Configuration
public class DataLoader {

    @Bean
    CommandLineRunner initDatabase(MovieRepository repository) {
        return args -> {
            long count = repository.count();
            System.out.println("📊 Current movie count: " + count);

            // 1. CLEANUP: If data looks broken (Title is a URL) or is test data, wipe it.
            boolean isBroken = false;
            if (count > 0) {
                // check the first movie to see if it's broken like your friend's
                Movie m = repository.findAll().get(0);
                if (m.getTitle().startsWith("http") || m.getOverview().matches("\\d{4}")) {
                    isBroken = true;
                }
            }

            if (isBroken || (count > 0 && count < 50)) {
                System.out.println("🧹 Detected BROKEN or TEST data. Wiping database...");
                repository.deleteAll();
                count = 0;
            }

            // 2. LOAD
            if (count == 0) {
                System.out.println("🚀 Database is empty. Loading movies...");
                List<Movie> movies = new ArrayList<>();

                try (BufferedReader br = new BufferedReader(new InputStreamReader(
                        new ClassPathResource("movies.csv").getInputStream()))) {

                    String line;
                    boolean isHeader = true;

                    while ((line = br.readLine()) != null) {
                        if (isHeader) { isHeader = false; continue; }

                        // Regex handles commas inside quotes
                        String[] data = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                        // We need at least 4 columns to try parsing
                        if (data.length >= 4) {
                            try {
                                String col0 = data[0].replace("\"", "").trim();

                                String title, posterUrl, overview;
                                List<String> genres;
                                Double popularity = 0.0; // Default value

                                // --- AUTO-DETECT FORMAT ---
                                if (col0.startsWith("http")) {
                                    // FORMAT A: KAGGLE / IMDB DATASET (Link, Title, Year, Cert, Runtime, Genre, Rating, Overview...)

                                    posterUrl = col0;
                                    title = data[1].replace("\"", "").trim();

                                    // Genre is usually index 5
                                    String genreString = (data.length > 5) ? data[5].replace("\"", "").trim() : "General";
                                    genres = Arrays.asList(genreString.split(","));

                                    // POPULARITY (IMDB Rating) is usually index 6
                                    if (data.length > 6) {
                                        try {
                                            String ratingStr = data[6].replace("\"", "").trim();
                                            popularity = Double.parseDouble(ratingStr);
                                        } catch (NumberFormatException e) {
                                            popularity = 5.0; // Fallback if rating is missing
                                        }
                                    }

                                    overview = (data.length > 7) ? data[7].replace("\"", "").trim() : "No description available.";

                                } else {
                                    // FORMAT B: YOUR CUSTOM FORMAT (Title, Poster, Overview, Genres)
                                    title = col0;
                                    String rawPoster = data[1].replace("\"", "").trim();
                                    overview = data[2].replace("\"", "").trim();
                                    String genreString = data[3].replace("\"", "").trim();
                                    genres = Arrays.asList(genreString.split(";"));

                                    // Your old CSV didn't have popularity, so give it a good default
                                    popularity = 7.5;

                                    // Fix partial URLs
                                    if (rawPoster.startsWith("http")) {
                                        posterUrl = rawPoster;
                                    } else {
                                        posterUrl = "https://image.tmdb.org/t/p/original" + rawPoster;
                                    }
                                }

                                // ADD NEW MOVIE WITH POPULARITY
                                movies.add(new Movie(title, posterUrl, overview, genres, popularity));

                            } catch (Exception e) {
                                // Skip rows that fail parsing
                                System.err.println("Skipping row due to error: " + e.getMessage());
                            }
                        }
                    }

                    if (!movies.isEmpty()) {
                        repository.saveAll(movies);
                        System.out.println("✅ SUCCESS! Loaded " + movies.size() + " movies.");
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                System.out.println("ℹ️ Database is ready.");
            }
        };
    }
}