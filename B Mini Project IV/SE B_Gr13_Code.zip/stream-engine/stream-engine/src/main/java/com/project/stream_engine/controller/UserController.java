package com.project.stream_engine.controller;

import com.project.stream_engine.model.Movie;
import com.project.stream_engine.model.User;
import com.project.stream_engine.repository.MovieRepository;
import com.project.stream_engine.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/user")
@CrossOrigin(origins = "*")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MovieRepository movieRepository;

    @PostMapping("/{userId}/watchlist/add/{movieId}")
    public ResponseEntity<?> addToWatchlist(@PathVariable String userId, @PathVariable String movieId) {
        System.out.println("🔹 Request received: Add Movie " + movieId + " to User " + userId);

        Optional<User> userOpt = userRepository.findById(userId);
        Optional<Movie> movieOpt = movieRepository.findById(movieId);

        if (userOpt.isPresent() && movieOpt.isPresent()) {
            User user = userOpt.get();
            Movie movie = movieOpt.get();

            boolean exists = user.getWatchlist().stream().anyMatch(m -> m.getId().equals(movieId));

            if (!exists) {
                user.getWatchlist().add(movie);
                userRepository.save(user); // Save to DB
                System.out.println("✅ SAVED to DB! User now has " + user.getWatchlist().size() + " movies.");
                return ResponseEntity.ok("Movie added!");
            } else {
                System.out.println("⚠️ Movie already in list.");
                return ResponseEntity.ok("Already added.");
            }
        }
        System.out.println("❌ User or Movie not found in DB.");
        return ResponseEntity.badRequest().body("Not found");
    }

    @GetMapping("/{userId}/watchlist")
    public ResponseEntity<List<Movie>> getWatchlist(@PathVariable String userId) {
        System.out.println("🔹 Fetching watchlist for User: " + userId);
        Optional<User> userOpt = userRepository.findById(userId);

        if (userOpt.isPresent()) {
            List<Movie> list = userOpt.get().getWatchlist();
            System.out.println("📤 Returning " + list.size() + " movies.");
            return ResponseEntity.ok(list);
        }
        System.out.println("❌ User not found during fetch.");
        return ResponseEntity.notFound().build();
    }

    // (Keep your remove method here too...)
    @DeleteMapping("/{userId}/watchlist/remove/{movieId}")
    public ResponseEntity<?> removeFromWatchlist(@PathVariable String userId, @PathVariable String movieId) {
        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            boolean removed = user.getWatchlist().removeIf(m -> m.getId().equals(movieId));
            if (removed) {
                userRepository.save(user);
                System.out.println("🗑️ Movie removed & Saved. Remaining: " + user.getWatchlist().size());
                return ResponseEntity.ok("Removed");
            }
        }
        return ResponseEntity.badRequest().body("Failed to remove");
    }
}