package com.project.stream_engine.controller;

import com.project.stream_engine.model.Movie;
import com.project.stream_engine.model.User;
import com.project.stream_engine.repository.MovieRepository;
import com.project.stream_engine.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/movies")
@CrossOrigin(origins = "*")
public class MovieController {

    @Autowired
    private MovieRepository movieRepository;

    @Autowired
    private UserRepository userRepository; // Needed for Collaborative Filtering

    // 1. Get Random Movies (For Dashboard)
    @GetMapping("/random")
    public List<Movie> getRandomMovies() {
        return movieRepository.findRandomMovies();
    }

    // 2. Search Movies
    @GetMapping("/search")
    public List<Movie> searchMovies(@RequestParam String query) {
        return movieRepository.findByTitleContainingIgnoreCase(query);
    }

    // 3. Get Movies by User's Favorite Genres (Personalization)
    @PostMapping("/by-genres")
    public List<Movie> getMoviesByGenres(@RequestBody List<String> genres) {
        if (genres == null || genres.isEmpty()) {
            return movieRepository.findRandomMovies();
        }
        return movieRepository.findByGenres(genres);
    }

    // 4. Add New Movie (For Admin Dashboard)
    @PostMapping("/add")
    public Movie addMovie(@RequestBody Movie movie) {
        if (movie.getGenres() == null || movie.getGenres().isEmpty()) {
            throw new RuntimeException("Movie must have at least one genre!");
        }
        return movieRepository.save(movie);
    }

    // 5. TRENDING ENDPOINT (New)
    @GetMapping("/trending")
    public List<Movie> getTrendingMovies() {
        return movieRepository.findTop10ByOrderByPopularityDesc();
    }

    // 6. COLLABORATIVE FILTERING ENDPOINT ("Users like you also watched...")
    @GetMapping("/collaborative/{userId}")
    public List<Movie> getCollaborativeRecommendations(@PathVariable String userId) {
        Optional<User> currentUserOpt = userRepository.findById(userId);
        if (currentUserOpt.isEmpty()) return new ArrayList<>();

        User currentUser = currentUserOpt.get();
        List<String> myGenres = currentUser.getFavoriteGenres();

        List<Movie> recommendations = new ArrayList<>();
        Set<String> addedMovieIds = new HashSet<>(); // To avoid duplicates

        // Add my own watchlist IDs to the "seen" set so I don't get recommended movies I already have
        if (currentUser.getWatchlist() != null) {
            for (Movie m : currentUser.getWatchlist()) {
                addedMovieIds.add(m.getId());
            }
        }

        // A. Find other users
        List<User> allUsers = userRepository.findAll();

        for (User otherUser : allUsers) {
            // Skip myself
            if (otherUser.getId().equals(userId)) continue;

            // B. Check if we share at least one genre (Simple Similarity Check)
            boolean sharesGenre = false;
            if (otherUser.getFavoriteGenres() != null) {
                for (String g : otherUser.getFavoriteGenres()) {
                    if (myGenres.contains(g)) {
                        sharesGenre = true;
                        break;
                    }
                }
            }

            // C. If we share taste, steal movies from their watchlist!
            if (sharesGenre && otherUser.getWatchlist() != null) {
                for (Movie m : otherUser.getWatchlist()) {
                    // Don't recommend what I already have
                    if (!addedMovieIds.contains(m.getId())) {
                        recommendations.add(m);
                        addedMovieIds.add(m.getId());
                    }
                }
            }
            if (recommendations.size() >= 10) break; // Limit recommendations to 10
        }

        return recommendations;
    }
}