package com.project.stream_engine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreamEngineApplicationTests {

	@Test
	void contextLoads() {
	}

}
